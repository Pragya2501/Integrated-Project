import React, { Component } from 'react'
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';

class Landing extends Component {

    componentDidMount() {
        if (this.props.security.validToken) {
            this.props.history.push("/dashboard");
        }
    }


    render() {
        return (

            <div className="landing">
                <div className="light-overlay landing-inner text-dark">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12 text-center">
                                <h1 className="display-3 mb-4">PPM Tool</h1>
                                <p className="lead">                                
                               <font size="6"
                               face="verdana"
                                   color="blue">                   
                                   Managing your Projetcs can be tough, but we can help!
                                   PPM Tool provides solutions on how to add new projects
                                                and manage your old ones.
                                </font> 
                                </p>
                                <hr />
                                <Link className="btn btn-lg btn-primary mr-2" to="/register">
                                    Join here
                                    </Link>
                                <Link className="btn btn-lg btn-secondary mr-2" to="/login">
                                    Login
                                </Link>
                            </div>                            
                            <footer>
                                <p>Creator: Pragya Tomar</p>
                                <p><a href="pragya@gmail.com">pragya@gmail.com</a></p>
                            </footer>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

Landing.propTypes = {
    security: PropTypes.object.isRequired
}

const mapStateToProps = state => ({
    security: state.security
})

export default connect(mapStateToProps)(Landing);